/**
 * E2E Test State Control helper.
 *
 * Wraps HTTP calls to test-state.php so Playwright tests can set
 * application state (season phase, trades, waivers, trivia, etc.)
 * and restore it after each test.
 */
import type { APIRequestContext } from '@playwright/test';

export type Settings = Record<string, string>;

export interface SetStateResult {
  previous: Settings;
  applied: Settings;
}

export async function getState(
  request: APIRequestContext,
): Promise<Settings> {
  const response = await request.get('test-state.php');
  if (!response.ok()) {
    throw new Error(
      `test-state.php GET failed: ${response.status()} ${await response.text()}`,
    );
  }
  return (await response.json()) as Settings;
}

export async function setState(
  request: APIRequestContext,
  settings: Settings,
): Promise<SetStateResult> {
  const response = await request.post('test-state.php', {
    data: settings,
  });
  if (!response.ok()) {
    throw new Error(
      `test-state.php POST failed: ${response.status()} ${await response.text()}`,
    );
  }
  return (await response.json()) as SetStateResult;
}

export async function setEoyVotes(
  request: APIRequestContext,
  count: number,
): Promise<void> {
  const response = await request.delete(
    `test-state.php?action=set-eoy-votes&count=${count}`,
  );
  if (!response.ok()) {
    throw new Error(
      `test-state.php set-eoy-votes failed: ${response.status()} ${await response.text()}`,
    );
  }
}

export async function setLeadersHtm(
  request: APIRequestContext,
  present: boolean,
): Promise<void> {
  const response = await request.delete(
    `test-state.php?action=set-leaders-htm&present=${present ? 1 : 0}`,
  );
  if (!response.ok()) {
    throw new Error(
      `test-state.php set-leaders-htm failed: ${response.status()} ${await response.text()}`,
    );
  }
}

export async function setChampion(
  request: APIRequestContext,
  year: number,
  present: boolean,
): Promise<void> {
  const response = await request.delete(
    `test-state.php?action=set-champion&year=${year}&present=${present ? 1 : 0}`,
  );
  if (!response.ok()) {
    throw new Error(
      `test-state.php set-champion failed: ${response.status()} ${await response.text()}`,
    );
  }
}

export async function setAward(
  request: APIRequestContext,
  year: number,
  award: string,
  present: boolean,
): Promise<void> {
  const response = await request.delete(
    `test-state.php?action=set-award&year=${year}&award=${encodeURIComponent(award)}&present=${present ? 1 : 0}`,
  );
  if (!response.ok()) {
    throw new Error(
      `test-state.php set-award failed: ${response.status()} ${await response.text()}`,
    );
  }
}

export async function setPlayerName(
  request: APIRequestContext,
  pid: number,
  name: string,
): Promise<string> {
  const response = await request.delete(
    `test-state.php?action=set-player-name&pid=${pid}&name=${encodeURIComponent(name)}`,
  );
  if (!response.ok()) {
    throw new Error(
      `test-state.php set-player-name failed: ${response.status()} ${await response.text()}`,
    );
  }
  const body = (await response.json()) as { previous: string };
  return body.previous;
}

export interface TeamVoteStatus {
  asg_vote: string;
  eoy_vote: string;
  asg_voted: boolean;
  eoy_voted: boolean;
}

export async function getVotes(
  request: APIRequestContext,
  team: string,
): Promise<TeamVoteStatus> {
  const response = await request.get(
    `test-state.php?action=get-votes&team=${encodeURIComponent(team)}`,
  );
  if (!response.ok()) {
    throw new Error(
      `test-state.php get-votes failed: ${response.status()} ${await response.text()}`,
    );
  }
  return (await response.json()) as TeamVoteStatus;
}

export async function resetVote(
  request: APIRequestContext,
  team: string,
  type: 'asg' | 'eoy',
): Promise<void> {
  const response = await request.delete(
    `test-state.php?action=reset-vote&team=${encodeURIComponent(team)}&type=${type}`,
  );
  if (!response.ok()) {
    throw new Error(
      `test-state.php reset-vote failed: ${response.status()} ${await response.text()}`,
    );
  }
}

export interface SeedResetUser {
  username: string;
  email: string;
  selector: string;
  token: string;
  oldPassword: string;
}

export interface SeedConfirmUser {
  username: string;
  email: string;
  selector: string;
  token: string;
}

/**
 * Seed a VERIFIED `e2e_reset_*` account and return a usable password-reset
 * selector/token pair (minted by delight-auth, since the reset row stores a
 * password_hash digest a raw INSERT cannot reproduce). Clean up with
 * deleteTestUser(request, result.username).
 */
export async function seedResetUser(
  request: APIRequestContext,
): Promise<SeedResetUser> {
  const response = await request.post(
    'test-state.php?action=seed-reset-user',
    { data: {} },
  );
  if (!response.ok()) {
    throw new Error(
      `seed-reset-user failed: ${response.status()} ${await response.text()}`,
    );
  }
  return (await response.json()) as SeedResetUser;
}

/**
 * Seed an UNVERIFIED `e2e_confirm_*` account and return the confirmation
 * selector/token pair so the confirm_email success round-trip can run.
 * Clean up with deleteTestUser(request, result.username).
 */
export async function seedConfirmUser(
  request: APIRequestContext,
): Promise<SeedConfirmUser> {
  const response = await request.post(
    'test-state.php?action=seed-confirm-user',
    { data: {} },
  );
  if (!response.ok()) {
    throw new Error(
      `seed-confirm-user failed: ${response.status()} ${await response.text()}`,
    );
  }
  return (await response.json()) as SeedConfirmUser;
}

export type SetStateFn = (settings: Settings) => Promise<SetStateResult>;

/**
 * Creates the legacy DB-mutating appState fixture.
 * Retained for test-state.spec.ts and future DB-mutation use cases.
 */
export function createAppStateFixture() {
  return async ({ request }: { request: APIRequestContext }, use: (fn: SetStateFn) => Promise<void>) => {
    const restoreStack: Settings[] = [];

    const setStateFn: SetStateFn = async (settings) => {
      const result = await setState(request, settings);
      restoreStack.push(result.previous);
      return result;
    };

    await use(setStateFn);

    // Teardown: restore previous values in reverse order
    for (const previous of restoreStack.reverse()) {
      const toRestore: Settings = {};
      for (const [key, value] of Object.entries(previous)) {
        if (value !== null) {
          toRestore[key] = value;
        }
      }
      if (Object.keys(toRestore).length > 0) {
        await setState(request, toRestore);
      }
    }
  };
}

/**
 * Creates a cookie-based appState fixture that eliminates DB race conditions.
 *
 * Instead of mutating ibl_settings rows (which parallel tests can overwrite),
 * this sets a `_test_overrides` cookie that PHP reads per-request. State travels
 * with the request — zero race window, no cleanup needed.
 */
export function createCookieStateFixture() {
  return async (
    { context }: { context: import('@playwright/test').BrowserContext },
    use: (fn: SetStateFn) => Promise<void>,
  ) => {
    let mergedOverrides: Settings = {};

    const setStateFn: SetStateFn = async (settings) => {
      mergedOverrides = { ...mergedOverrides, ...settings };
      const encoded = encodeURIComponent(JSON.stringify(mergedOverrides));
      const baseUrl = process.env.BASE_URL ?? 'http://main.localhost/ibl5/';
      await context.addCookies([{
        name: '_test_overrides',
        value: encoded,
        domain: new URL(baseUrl).hostname,
        path: '/',
      }]);
      return { previous: {}, applied: settings };
    };

    await use(setStateFn);
    // No teardown needed — cookies are scoped to the browser context
  };
}
